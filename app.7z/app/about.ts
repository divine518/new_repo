import { Component } from '@angular/core';
@Component({
  selector: 'about',
  templateUrl:'./about.html'
})
export class About {
  currentSection = 'section1';

  onSectionChange(sectionId: string) {
    this.currentSection = sectionId;
  }

  scrollTo(section) {
    document.querySelector('#' + section)
    .scrollIntoView();
  }
} 