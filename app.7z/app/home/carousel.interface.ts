export interface Slide {
    headline?: string;
    src: string; 
  }
  