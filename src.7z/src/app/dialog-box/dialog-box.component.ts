
//dialog-box.component.ts
import { Component, Inject, Optional, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { Location } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA, MatTable, MatTableModule } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClientService } from '../service/http-client.service';
import { Router } from '@angular/router';
import { EditComponent } from '../edit/edit.component';

export interface UsersData {
  name: string;
  id: number;
}


@Component({
  selector: 'app-dialog-box',
  templateUrl: './dialog-box.component.html',
  styleUrls: ['./dialog-box.component.scss']
})
export class DialogBoxComponent implements OnInit{
@Output() myEvent=new EventEmitter();
  updForm: any;
  action: string;
  local_data: any;
  compProp: any;
  compValues: any;
  updateForm: FormGroup;
  response: any;
  
  constructor(private location:Location, public edit:MatTableModule ,private service: HttpClientService, private router: Router, private formBuilder: FormBuilder, public dialogRef: MatDialogRef<DialogBoxComponent>, @Optional() @Inject(MAT_DIALOG_DATA) public data: UsersData) {
   
    this.updateForm = this.formBuilder.group({
      user_id: ['', Validators.required],
      name: ['', Validators.required],
      age: ['', Validators.required],
      mobileNumber: ['', Validators.required],
      emailId: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required],
      area: ['', Validators.required],
      bloodGroup: ['', Validators.required]
    });
    //this.updateForm.controls['user_id'].readOnly=true;
    this.local_data = { ...data };
    this.action = this.local_data.action;
    console.log(this.local_data);
    this.compProp = Object.keys(this.local_data);
    this.compValues = Object.values(this.local_data);
    for (let i = 0; i < this.compProp.length - 1; i++) {
      console.log(this.compProp[i]);
      if(this.updateForm.get(this.compProp[i])!=null){
 
      this.updateForm.get(this.compProp[i]).setValue(this.compValues[i]);
      }
    }

  }
  ngOnInit(): void {
   // this.dialogRef.updateSize("340px", "700px");
  }
  doAction() {
    //this.dialogRef.close({event:this.action,data:this.local_data});
    if(this.action=='Update'){
         this.updForm = this.updateForm.value;
    }
    else if(this.action=='Delete'){
this.updForm=this.local_data;
    }
    this.service.iDoUpdate(this.updForm,this.action).subscribe((response) => {
      this.response = response;
      if (this.response.message != null && this.response.message != undefined) {
        if (this.response.message == "success") {
          alert(this.action+" success");
          this.dialogRef.close({event:this.action,data:this.local_data});
          //this.router.navigate(["edit"]);
        this.myEvent.emit();
         this.location.back();

        }
        else if (this.response.message == "failure") {
          alert(this.action+" failed");
          this.dialogRef.close({event:'Cancel'});
        }
      }
    });
  
  }
  closeDialog() {
    this.dialogRef.close({ event: 'Cancel' });
  }
}





