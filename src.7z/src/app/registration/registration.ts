import { Component,OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from "@angular/forms";
import {Router} from '@angular/router';
import { HttpClientService } from '../service/http-client.service';
export interface dropDown {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'registration',
  templateUrl: './registration.html'
})

export class Registration implements OnInit{
  public reg:any;
  regForm:any;
  registrationForm:FormGroup;
  response: any;
  constructor(private router: Router, private formBuilder: FormBuilder, private service: HttpClientService) {
    this.createForm();
   
   }ngOnInit(){
  
  }
   createForm() {
    this.registrationForm = this.formBuilder.group({
      user_id: ['',Validators.required],
       name: ['', Validators.required ],
       age: ['', Validators.required ],
       mobileNumber: ['', Validators.required ],
       emailId: ['', Validators.required ],
       state: ['', Validators.required ],
       area: ['', Validators.required ],
       bloodGroup: ['', Validators.required ]
    });
  }
rad='';
onRegClick(){
  console.log(this.registrationForm.value);
 this.regForm=this.registrationForm.value;
 this.service.iDoRegistration(this.regForm).subscribe((response)=>{
   console.log(response);
   this.response=response;
   if(this.response.message!=null&&this.response.message!=undefined){
    if(this.response.message=="success"){
      alert("Congrats!!..Registered succesfully");
      this.router.navigate(["home"]);
    }
    else if(this.response.message=="failure") {
      alert("UserId already exists");
    }
  }
});
}
bloods: dropDown[] = [
  {value: 'A+', viewValue: 'A+'},
  {value: 'A-', viewValue: 'A-'},
  {value: 'B+', viewValue: 'B+'},
  {value: 'B-', viewValue: 'B-'},
  {value: 'O-', viewValue: 'O-'},
  {value: 'O+', viewValue: 'O+'},
  {value: 'AB+', viewValue: 'AB+'},
  {value: 'AB-', viewValue: 'AB-'}
];

states: dropDown[] = [
  {value: 'Odisha', viewValue: 'Odisha'},
  {value: 'Tamilnadu', viewValue: 'Tamilnadu'},
  {value: 'Maharashtra', viewValue: 'Maharashtra'},
  {value: 'Karnataka', viewValue: 'Karnataka'},
  {value: 'Telengana', viewValue: 'Telengana'},
  {value: 'Andhra Pradesh', viewValue: 'Andhra Pradesh'},
  {value: 'Kerala', viewValue: 'Kerala'},
  {value: 'West Bengal', viewValue: 'West Bengal'},
  {value: 'Chattisgarh', viewValue: 'Chattisgarh'},
  {value: 'Jharkhand', viewValue: 'Jharkhand'},
  {value: 'Uttar Pradesh', viewValue: 'Uttar Pradesh'},
  {value: 'Madhy Pradesh', viewValue: 'Madhy Pradesh'},
  {value: 'Sikkim', viewValue: 'Sikkim'},
  {value: 'Punjab', viewValue: 'Punjab'},
  {value: 'Gujarat', viewValue: 'Gujarat'},
  {value: 'Haryana', viewValue: 'Haryana'}
];



}