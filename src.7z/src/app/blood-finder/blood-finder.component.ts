import { Component, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { HttpClientService } from '../service/http-client.service';
export interface PeriodicElement {
  Name: string;
  No: number;
  Blood: string;
  Place: string;
}
export interface dropDown {
  value: string;
  viewValue: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {No: 1, Name: 'Nivetha', Blood: 'B+', Place: 'H'},
  {No: 2, Name: 'Tamil', Blood:'B-', Place: 'He'},
  {No: 3, Name: 'Murugan', Blood: 'B+', Place: 'Li'},
  {No: 4, Name: 'Siva', Blood: 'A-', Place: 'Be'}
];

@Component({
  selector: 'app-blood-finder',
  templateUrl: './blood-finder.component.html',
  styleUrls: ['./blood-finder.component.scss']
})
export class BloodFinderComponent implements OnInit {
  model: any = {};
  blood = new FormControl('', [Validators.required]);
public compProp:any=[];
public dataSource:any=[];
bloodSearchForm:FormGroup;
  response: Object;
  columnheader: any;
  constructor(
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer, private service: HttpClientService, private formBuilder: FormBuilder
  ){
    this.matIconRegistry.addSvgIcon(
      "blood",
      this.domSanitizer.bypassSecurityTrustResourceUrl("../../assets/images/blood_icon.svg")
    ) 
  }
  ngOnInit() {
    this.compProp=["name","mobileNumber","age","bloodGroup","emailId","state","area"];
    this.columnheader=["Name","Mobile","Age","Blood Group","Email","State","City"];
  console.log(this.compProp);
  console.log(this.dataSource);

  this.createForm();
  this.service.iGetVolunteerDetails().subscribe((response)=>{
    this.response=response;
    if(this.response!=null&&this.response!=undefined){
      this.dataSource=this.response;   
   }
 });

 // this.loadGrid();
  }
    createForm() {
    this.bloodSearchForm = this.formBuilder.group({
       state: ['', Validators.required ],
       area: ['', Validators.required ],
       bloodGroup: ['', Validators.required ]
    });
  }
  loadGrid(){
    console.log(this.bloodSearchForm);
    this.service.iGetBloodDonorDetails(this.bloodSearchForm.value).subscribe((response)=>{
      console.log(this.bloodSearchForm);
      this.response=response;
      if(this.response!=null&&this.response!=undefined){
        this.dataSource=this.response;   
     }
   });
 // this.dataSource = this.ELEMENT_DATA;
  }
  onSearchClick(values){
    console.log(values);
    this.loadGrid();
  }
  bloods: dropDown[] = [
    {value: 'A+', viewValue: 'A+'},
    {value: 'A-', viewValue: 'A-'},
    {value: 'B+', viewValue: 'B+'},
    {value: 'B-', viewValue: 'B-'},
    {value: 'O-', viewValue: 'O-'},
    {value: 'O+', viewValue: 'O+'},
    {value: 'AB+', viewValue: 'AB+'},
    {value: 'AB-', viewValue: 'AB-'}
  ];

  states: dropDown[] = [
    {value: 'Odisha', viewValue: 'Odisha'},
    {value: 'Tamilnadu', viewValue: 'Tamilnadu'},
    {value: 'Maharashtra', viewValue: 'Maharashtra'},
    {value: 'Karnataka', viewValue: 'Karnataka'},
    {value: 'Telengana', viewValue: 'Telengana'},
    {value: 'Andhra Pradesh', viewValue: 'Andhra Pradesh'},
    {value: 'Kerala', viewValue: 'Kerala'},
    {value: 'West Bengal', viewValue: 'West Bengal'},
    {value: 'Chattisgarh', viewValue: 'Chattisgarh'},
    {value: 'Jharkhand', viewValue: 'Jharkhand'},
    {value: 'Uttar Pradesh', viewValue: 'Uttar Pradesh'},
    {value: 'Madhy Pradesh', viewValue: 'Madhy Pradesh'},
    {value: 'Sikkim', viewValue: 'Sikkim'},
    {value: 'Punjab', viewValue: 'Punjab'},
    {value: 'Gujarat', viewValue: 'Gujarat'},
    {value: 'Haryana', viewValue: 'Haryana'}
  ];
}
