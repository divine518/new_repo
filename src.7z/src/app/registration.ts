import { Component } from '@angular/core';
@Component({
  selector: 'registration',
  templateUrl: './registration.html'
})
export class Registration {
rad='';
changeFun(){
  alert('hi');
}
}