import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
@Injectable({
    providedIn: 'root'
})
export class HttpClientService {

    constructor(private httpClient: HttpClient) { }
    values: string[];
    loginVerification(userName, password) {
        let params = new HttpParams().set('userName', userName);
        params = params.append('password', password);
        return this.httpClient.get('http://localhost:8080/api/login', { params: params })
    }
    eventUpload(eventForm, file) {

        console.log(eventForm)
        const uploadData = new FormData();

  let params = new HttpParams();
  var keys = Object.keys(eventForm);
  this.values = Object.values(eventForm);

  for (let i = 0; i < keys.length; i++) {
      uploadData.append(keys[i], this.values[i]);
  }
uploadData
  .append('file', file);
console.log(uploadData)
        return this.httpClient.post('http://localhost:8080/api/eventUpload', uploadData)
        //return null;
    }
    iDoRegistration(regForm) {

        let params = new HttpParams();
        var keys = Object.keys(regForm);
        this.values = Object.values(regForm);

        for (let i = 0; i < keys.length; i++) {
            if(keys[i] == 'bloodGroup'){
                params = params.append(keys[i], encodeURIComponent(this.values[i]));
                console.log('test')
                console.log(encodeURIComponent(this.values[i]))
            } else{
                params = params.append(keys[i], this.values[i]);
            }
          
        }
        return this.httpClient.get('http://localhost:8080/api/registration', { params: params })
    }
    iDoUpdate(updateForm, userAction) {

        console.log(updateForm)
        let params = new HttpParams();
        var keys = Object.keys(updateForm);
        this.values = Object.values(updateForm);

        for (let i = 0; i < keys.length; i++) {
            if(keys[i] == 'bloodGroup'){
                params = params.append(keys[i], encodeURIComponent(this.values[i]));
                console.log('test')
                console.log(encodeURIComponent(this.values[i]))
            } else{
                params = params.append(keys[i], this.values[i]);
            }
        }
         params = params.append("userAction", userAction);

        return this.httpClient.get('http://localhost:8080/api/update', { params: params });
    }
    iGetVolunteerDetails() {
        return this.httpClient.get('http://localhost:8080/api/getAllUser');
    }
    iGetBloodDonorDetails(bloodForm) { 
        let params = new HttpParams();
        var keys = Object.keys(bloodForm);
        this.values = Object.values(bloodForm);
        for (let i = 0; i < keys.length; i++) {
            if(keys[i] == 'bloodGroup'){
                params = params.append(keys[i], encodeURIComponent(this.values[i]));
                console.log('test')
                console.log(encodeURIComponent(this.values[i]))
            } else{
                params = params.append(keys[i], this.values[i]);
            }
        } 
        return this.httpClient.get('http://localhost:8080/api/getBloodFinderDetails', { params: params });
    }
    fetchImages(){
        return this.httpClient.get('http://localhost:8080/api/fetchEventDetails');
    }
}