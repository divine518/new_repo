import { BrowserModule } from '@angular/platform-browser';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import {MatMenuModule} from '@angular/material/menu';
import {MatButtonModule} from '@angular/material/button';
import { MglTimelineModule } from 'angular-mgl-timeline';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {About} from './about/about';
import {Home} from './home/home';
import {Registration} from './registration/registration';
import {Report} from './report/report';
import {EventUpload} from './eventUpload/eventUpload';
import {MatCardModule} from '@angular/material/card';
import {MatInputModule} from '@angular/material/input';
import {FormsModule} from '@angular/forms';
import {MatRadioModule} from '@angular/material/radio';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule,MatSelectModule, MatRipple} from '@angular/material';
import { ScrollSpyDirective } from './scroll-spy.directive';
//import { MDBBootstrapModule } from 'angular-bootstrap-md';   
import { LoremIpsumComponent } from './lorem-ipsum.component';
import { MatRippleModule } from '@angular/material';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'; 
import {  ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { BloodFinderComponent } from './blood-finder/blood-finder.component';
import {MatTableModule} from '@angular/material/table';
import { FusionChartsModule } from 'angular-fusioncharts';


// Load FusionCharts
import * as FusionCharts from 'fusioncharts';
// Load Charts module
import * as Charts from 'fusioncharts/fusioncharts.charts';
// Load themes
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
FusionChartsModule.fcRoot(FusionCharts, Charts, FusionTheme);
import { FooterComponent } from './footer/footer.component';
import { TimelineComponent } from './timeline/timeline.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import {
  MatToolbarModule,
  MatTabsModule,
  NativeDateModule,
  MatCheckboxModule,
  MatDialogModule
} from '@angular/material';
import { MatFileUploadModule } from 'angular-material-fileupload';
import { DomSanitizer } from "@angular/platform-browser";
import { EditComponent } from './edit/edit.component';
import { DialogBoxComponent } from './dialog-box/dialog-box.component';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    About,
    Home,
    Registration,
    Report,
    EventUpload,
  ScrollSpyDirective, 
  LoremIpsumComponent,
  LoginComponent,
  BloodFinderComponent,
  FooterComponent,
  TimelineComponent,
  EditComponent,
  DialogBoxComponent

  ],
  imports: [
    
    FusionChartsModule,
    BrowserModule,
    MatProgressSpinnerModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatMenuModule,
    MatButtonModule,
    MatCardModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatIconModule,
    HttpClientModule,
    MatRippleModule,
    //MDBBootstrapModule.forRoot(),
    NgbModule,
    MatTableModule,
    MDBBootstrapModule.forRoot(),
    MatToolbarModule,
  MatTabsModule,
  NativeDateModule,
  MatCheckboxModule,
  MglTimelineModule 
  ,MatFileUploadModule,
  MatDialogModule
   // ,DomSanitizer
  ],
  entryComponents: [
    DialogBoxComponent
  ],
  exports:[MatRipple,MatIconModule],
  providers: [],
  bootstrap: [AppComponent]

})
export class AppModule {}
