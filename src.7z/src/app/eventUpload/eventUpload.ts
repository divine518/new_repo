import { Component,OnInit,NgZone } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from "@angular/forms";
import { HttpClientService } from '../service/http-client.service';
//import {FormBuilder, FormGroup, Validators, FormControl} from "@angular/forms";
import {Router} from '@angular/router';
@Component({
  selector: 'eventUpload',
  templateUrl: './eventUpload.html'
})
export class EventUpload{
  eventForm: any;
  response: any;
  constructor(private service: HttpClientService,private router: Router, private formBuilder: FormBuilder,) { 
    this.eventUploadForm = this.formBuilder.group({
      title: ['',Validators.required],
       description: ['', Validators.required ],
       eventDateinString: ['', Validators.required ],
       venue: ['', Validators.required ],
       pic: ['', Validators.required ]
    });
  }
  selectedFile: File;
  receivedImageData: any;
  base64Data: any;
  imgURL: any;
  convertedImage: any;
  eventUploadForm:FormGroup;

 
  onFileChanged(event) {
    this.selectedFile = event.target.files[0];
   // this.pic = this.selectedFile;
    let reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event2) => {
      this.imgURL = reader.result;
    };
  }

  onUpload() {
  
    this.eventForm=this.eventUploadForm.value;
    this.service.eventUpload(this.eventForm, this.selectedFile).subscribe((response)=>{
      this.response = response;
      if (this.response.message != null && this.response.message != undefined) {
        if (this.response.message == "success") {
          alert(" success");
        }
        else if (this.response.message == "failure") {
          alert(" failed");
        }
      }
    });
    // this.http.post('my-backend.com/file-upload', this.selectedFile)
    // .subscribe(event => {
    //   console.log(event); // handle event here
    // });

  }
  
  }
   