import { Component } from '@angular/core';
@Component({
  selector: 'bloodFinder',
  template: ' <mat-card>Here we can find the blood</mat-card>'
})
export class BloodFinder {
}