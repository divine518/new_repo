import { Component,OnInit,NgZone } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from "@angular/forms";

@Component({
  selector: 'report',
  templateUrl: './report.html'
})

export class Report implements OnInit{
  dataSource: any;
  selectedSlice = 'none';
  chart: any;
  barGraph: Object;
    chartConfig: Object;
content:any;
contentArray:any;
  constructor(private zone: NgZone) {
  this.contentArray= [{
    "label": "Education",
    "title":"Education",
    "text": "These are education Details. Phoenix Organizational Trust is a non-profit organization that was started in the year 2015 and it is registered on 31st March 2017. Mr. G.DINESH is the founder and Managing Trustee of this Organization. It is a grass root organization that focuses on Agriculture, Education, Environment, Employment and Community welfare"
}, {
    "label": "DisasterManagemnet",
    "title":"Disaster Managemnet",
    "text": "These are DisasterManagemnet Details"
}, {
    "label": "Health",
    "title":"Health",
    "text": "These are Health Details"
}, {
    "label": "Farming",
    "title":"Farming",
    "text": "These are Farming Details"
},
{
  "label": "Other",
  "title":"Other",
  "text": "These are Other Details"
}];

    this.dataSource = {
      "chart": {
          "caption": "Annual Report",
          "plottooltext": "$label servers",
          "showLegend": "1",
          "showPercentValues": "1",
          "legendPosition": "bottom",
          "useDataPlotColorForLabels": "1",
          "enablemultislicing": "0",
          "showlegend": "0",
          "theme": "fusion",
      },
      "data": [{
          "label": "Education",
          "value": "35"
      }, {
          "label": "DisasterManagemnet",
          "value": "15"
      }, {
          "label": "Health",
          "value": "35"
      }, {
          "label": "Farming",
          "value": "15"
      },
      {
        "label": "Other",
        "value": "10"
    }]
    };
  }

  // FusionCharts initialized listener to get the chart instance
  initialized($event){
    this.chart = $event.chart;
    console.log($event.chart); // saving chart instance
  }

  // Change listener for radio buttons
  onRadioOptionChange(option){
    this.selectedSlice = option;
    // For each data element , see if it is selected, if none then slice in all elements
    this.dataSource.data.forEach((d, index) => {
      if(option == 'none'){
        this.chart.slicePlotItem(index, false);
      } else if(option === d.label.toLowerCase()){
        this.chart.slicePlotItem(index, true);
      }
    });
  }

  // Get data item label
  getLabel(index){
    return this.dataSource.data[index].label;
  }

  // FusionCharts Component dataPlot click listener
  dataplotClick($event){
    //alert('ss');
    let dataIndex = $event.dataObj.dataIndex;
    let isSliced = $event.dataObj.isSliced;
    console.log( $event);
    this.content=$event.dataObj.categoryLabel;
    
    console.log(isSliced);
    this.zone.run(() => {
      this.selectedSlice = isSliced ? 'none' : this.getLabel(dataIndex).toLowerCase();
    })
  }

  ngOnInit() {
    // setTimeout(() => {
    //   SelectedSingleton.change(this.sampleCode['ex24'].title);
    // })
  }

  
  }
   