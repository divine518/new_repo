import { Component, OnInit,ViewChild  } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';  
import { NgbCarousel } from '@ng-bootstrap/ng-bootstrap';
import { NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import { trigger,style,animate,transition, useAnimation, keyframes } from "@angular/animations";
import {
  scaleIn,
  scaleOut,
} from "./carousel.animations";
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'home',
  templateUrl:'./home.html',
  styleUrls:['./home.scss'],
   animations: [
    trigger('carouselAnimation', [
      transition('void => *', [
        style({ opacity: 0, transform: "scale(0.5)" }), // start state
  animate(
    "300ms",
    style({ opacity: 1, transform: "scale(1)" })
  )
      ]),
      transition('* => void', [
        animate(
          "300ms",
          style({ opacity: 0, transform: "scale(0.5)" })
        )
      ])
    ])
  
  ]
})

export class Home implements OnInit{
  @ViewChild('ngcarousel', { static: true }) ngCarousel: NgbCarousel;
  public slides = [
    //
    //{ src: "assets/images/2.jpg" },
    {src: "assets/images/p1.jpg"},
    {src: "assets/images/p2.jpg"},
    { src: "assets/images/che.jpg" }
  ];
  images:any
  private service: HttpClientService;
  response: any;
  ngOnInit(){ 
    // document.body.classList.add('bg-img');
     
    this.service.fetchImages().subscribe((response)=>{
      this.response=response;
     // this.receivedImageData = response;
                  //     this.base64Data = this.receivedImageData.pic;
                  if(this.response!=null&&this.response!=undefined){
                    this.images  = 'data:image/jpeg;base64,' + this.response.pic; 
                  }
    });
console.log(this.images);

     }
  // navigateToSlide(item) {
  //   this.ngCarousel.select(item);
  //   console.log(item)
  // }

  // // Move to previous slide
  // getToPrev() {
  //   this.ngCarousel.prev();
  // }

  // // Move to next slide
  // goToNext() {
  //   this.ngCarousel.next();
  // }

  // // Pause slide
  // stopCarousel() {
  //   this.ngCarousel.pause();
  // }

  // // Restart carousel
  // restartCarousel() {
  //   this.ngCarousel.cycle();
  // }
  currentSlide = 0;

  onPreviousClick() {
    const previous = this.currentSlide - 1;
    this.currentSlide = previous < 0 ? this.slides.length - 1 : previous;
    console.log("previous clicked, new current slide is: ", this.currentSlide);
  }

  onNextClick() {
    const next = this.currentSlide + 1;
    this.currentSlide = next === this.slides.length ? 0 : next;
    console.log("next clicked, new current slide is: ", this.currentSlide);
  }
  constructor(config: NgbCarouselConfig) {  
    // config.interval = 2000;  
    // config.wrap = true;  
    // config.keyboard = false;  
    // config.pauseOnHover = false;  
  }    
  // slideActivate(ngbSlideEvent: NgbSlideEvent) {
  //   console.log(ngbSlideEvent.source);
  //   console.log(ngbSlideEvent.paused);
  //   console.log(NgbSlideEventSource.INDICATOR);
  //   console.log(NgbSlideEventSource.ARROW_LEFT);
  //   console.log(NgbSlideEventSource.ARROW_RIGHT);
  // }
    
//     $("#myCarousel").carousel();

// // Enable Carousel Indicators
// $(".item").click(function(){
//   $("#myCarousel").carousel(1);
// });

// // Enable   Controls
// $(".left").click(function(){
//   $("#myCarousel").carousel("prev");
// });

} 