import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTable, MatDialog } from '@angular/material';
import { DialogBoxComponent } from '../dialog-box/dialog-box.component';
import {Router} from '@angular/router';
import { HttpClientService } from '../service/http-client.service';
export interface PeriodicElement {
  Name: string;
  Age:string;
  Mobile:string;
  Email:string;
State:string;
City:string;
  Blood: string;
  Area: string;
}

// PeriodicElement[] = [
//   {Name: 'APJ',Age: '21',Mobile: '12345',Email: 'APJ@gmail',State: 'TN',City: 'Rameswaram', Blood: 'B+', Area: 'srgm'},
//   {Name: 'Che guevara',Age: '22',Mobile: '768786',Email: 'Che@gmail',State: 'Havana',City: 'hav', Blood: 'A+', Area: 'aundh'},
//   {Name: 'Fiedel castro',Age: '34',Mobile: '4353543',Email: 'fiedel@gmail',State: 'Havana',City: 'hav', Blood: 'O+', Area: 'vimanagar'},
//   {Name: 'Mandela',Age: '24',Mobile: '56465',Email: 'mandela@gmail',State: 'SA',City: 'SA-cape', Blood: 'AB+', Area: 'pimpri'}
// ];
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})

export class EditComponent implements OnInit {
  public compProp:any=[];
  public dataSource:any=[];
  ELEMENT_DATA:any; response: any;
  @ViewChild(MatTable,{static:true}) table: MatTable<any>;
  comp: string[];
  
  constructor(public dialog: MatDialog,private router: Router,private service:HttpClientService) { }

  ngOnInit() {
    this.compProp=["user_id","name","age","mobileNumber","emailId","state","city","area","bloodGroup","Action"];
    this.comp=["User Id","Name","Age","Contact Number ","Email","State","City","Area","Blood Group","Action"];
    this.loadGrid();
  }
  loadGrid(){
    this.service.iGetVolunteerDetails().subscribe((response)=>{
      this.response=response;
      if(this.response!=null&&this.response!=undefined){
        this.ELEMENT_DATA=this.response;   
     }
   });
  this.dataSource = this.ELEMENT_DATA;
  }
  openDialog(action,obj) {
    obj.action = action;
    console.log(obj);
    if(obj.action == 'Add'){
      this.router.navigate(["registration"]);
    } else{
      const dialogRef = this.dialog.open(DialogBoxComponent, {
        width: '250px',
        data:obj
      });
    }
   
 
    // dialogRef.afterClosed().subscribe(result => {
    //   if(result.event == 'Add'){
    //    // this.addRowData(result.data);
    //    this.router.navigate(["home"]);
    //   }else if(result.event == 'Update'){
    //     this.updateRowData(result.data);
    //   }else if(result.event == 'Delete'){
    //     this.deleteRowData(result.data);
    //   }
    // });
  }
  // updateRowData(row_obj){
  //   this.dataSource = this.dataSource.filter((value,key)=>{
  //     if(value.id == row_obj.id){
  //       value.name = row_obj.name;
  //     }
  //     return true;
  //   });
  // }
  // deleteRowData(row_obj){
  //   this.dataSource = this.dataSource.filter((value,key)=>{
  //     return value.id != row_obj.id;
  //   });
  // }
}
