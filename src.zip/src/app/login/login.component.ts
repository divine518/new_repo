import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { HttpClientService } from '../service/http-client.service';
//import { PushNotificationOptions, PushNotificationService } from 'ngx-push-notifications';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
   styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
//  constructor(private router: Router, private service: HttpClientService,private _pushNotificationService: PushNotificationService) { }
constructor(private router: Router, private service: HttpClientService) { }
username: string;
password: string;
response:any;
  ngOnInit() {
   // this._pushNotificationService.requestPermission();
  }
  login() : void {
    
    if(this.username != null && this.password != null){
      this.service.loginVerification(this.username,this.password).subscribe((response)=>{
        this.response=response;
        console.log("response------->"+this.response.response)
        if(this.response.response!=null&&this.response.response!=undefined){
          if(this.response.response=="success"){
            this.router.navigate(["home"]);
          }
          else if(this.response.response=="failure") {
            alert("Invalid credentials");
          }
        }
    else{
      alert("unable to verify");
    }
      });
     
    }
  }
  }
