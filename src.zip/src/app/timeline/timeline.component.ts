import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss']
})

export class TimelineComponent  implements OnInit{
  alternate: boolean = true;
  toggle: boolean = false;
  color: boolean = false;
  size: number = 40;
  expandEnabled: boolean = true;
  side = 'left';
  constructor() { }

  ngOnInit() {
  }
  entries = [
    {
      header: 'The Beginning',
      isMultiContent:false,
      content: 'Phoenix Organizational Trust is a non-profit organization that was started in the year 2015 and it is registered on 31st March 2017. Mr. G.DINESH is the founder and Managing Trustee of this Organization. It is a grass root organization that focuses on Agriculture, Education, Environment, Employment and Community welfare'
    },
    {
      header: 'Our Leaders',
      isMultiContent:true,
      content:['Mr. G.Dinesh – Founder Cum Managing Trustee',
      'Ms. M.Hemalatha - Secretary cum Financial Trustee',
     'Mr. J.Syed Abdul Raheem – Trustee'
    ]},
    {
      header: 'In Media',
      isMultiContent:false,
      content: 'Got Appreciations from many medias like The Hindu,Dinakaran and so on '
    },
    {
      header: 'Contact Us', 
      isMultiContent:true,
      content: ['Phoenix Organizational Trust', 
        '373 20 House Sokkalingapuram  Mathur', 
        'Pudukkottai , Tamilnadu, India',
        'Pin code-622515',
        'Phone: 9087500534',
        'E-mail: phoenixtrust22@gmail.com',
        'Facebook : Phoenix Organizational Trust',
        'Youtube: Phoenix Trust',
        'Twitter: Phoenix_trust22'
        ]
    } 
  ]

  // addEntry() {
  //   this.entries.push({
  //     header: 'header',
  //     content: 'content'
  //   })
  // }

  // removeEntry() {
  //   this.entries.pop();
  // }

  onHeaderClick(event) {
    if (!this.expandEnabled) {
      event.stopPropagation();
    }
  }

  onDotClick(event) {
    if (!this.expandEnabled) {
      //event.stopPropagation();
    }
  }

  onExpandEntry(expanded, index) {
    console.log(`Expand status of entry #${index} changed to ${expanded}`)
  }

  toggleSide() {
    this.side = this.side === 'left' ? 'right' : 'left';
  }
}

