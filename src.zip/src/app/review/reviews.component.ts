import { Component, AfterViewInit } from '@angular/core';
import { environment } from 'src/environments/environment';

declare const google: any;

@Component({
  selector: 'app-reviews',
  template: `
    <div id="googleReviews"></div>
    <section id='reviews'>
    <div id="title">
      <h4>Google Reviews</h4>
    </div>
    <div id="reviews" class="row">
      <mat-card *ngFor="let review of reviews" class="card">
        <mat-card-header>
          <div class="avatar" mat-card-avatar>
            <img src="{{ review.profile_photo_url }}" alt="Avatar" height="50" 
             width="50" />
          </div>
          <mat-card-title>{{ review.author_name }}</mat-card-title>
          <h6>{{ review.relative_time_description }}</h6>
          <div class="stars"><mat-icon *ngFor="let item of 
           createRange(review.rating)">grade</mat-icon></div>
        </mat-card-header>
        <mat-card-content>
          <p>{{ review.text }}</p>
        </mat-card-content>
      </mat-card>
    </div>
    <div class="rowButton">
      <a mat-raised-button href="https://www.google.com/maps/place/Phoenix+Organizational+Trust/@10.7089488,78.7255768,17z/data=!3m1!4b1!4m7!3m6!1s0x0:0x1d4025fa4cf33b33!8m2!3d10.7089488!4d78.7277655!9m1!1b1" target="_blank">View all reviews</a>
    </div>
    </section>
  `,
  styleUrls: ['./reviews.component.scss']
})
export class ReviewsComponent implements AfterViewInit {
  service;
  public reviews = [];

  constructor() {}

  ngAfterViewInit() {
    const request = {
      placeId: "ChIJDRyMHZWLqjsRMzvzTPolQB0",
      fields: ['reviews']
    };
    this.service = new google.maps.places.PlacesService(document.getElementById('googleReviews'));

    this.service.getDetails(request, this.callback);
  }

  public callback = (place, status) => {
    if (status === google.maps.places.PlacesServiceStatus.OK) {
      this.reviews = place.reviews.slice();
    }
  };

  createRange(number) {
    const items: number[] = [];
    for (let i = 1; i <= number; i++) {
      items.push(i);
    }
    return items;
  }
}